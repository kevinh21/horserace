export function getMoviesById() {}
function some() {}
function some1() {}
function some2() {}
function some3() {}

export { some, some1, some2, some3 };
