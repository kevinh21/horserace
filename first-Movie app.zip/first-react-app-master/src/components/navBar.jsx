import { Component } from 'react';

class NavBar extends Component {
  render() {
    return <h2>Class Component</h2>;
  }
}

export default NavBar;
