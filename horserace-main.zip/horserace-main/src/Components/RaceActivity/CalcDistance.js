import React from "react";

const CalcDistance = (props) => {
  props.func("Hello World");

  return (
    <>
      <h1>This is the Child Component!</h1>
    </>
  );
};

export default CalcDistance;
