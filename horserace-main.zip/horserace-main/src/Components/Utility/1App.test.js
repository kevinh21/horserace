import React from "react";

function test(props) {
  return (
    <div>
      <h1>DONE</h1>
    </div>
  );
}

export default test;
