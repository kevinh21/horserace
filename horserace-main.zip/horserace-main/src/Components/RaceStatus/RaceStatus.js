import React from "react";
// import "./RaceStatus.css"
function RaceStatus(props) {
  return <div></div>;
}

export default RaceStatus;
