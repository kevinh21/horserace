import React from "react";

function SelectionData(props) {
  return <div></div>;
}

export default SelectionData;
