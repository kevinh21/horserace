// import React from "react";

// function Generator(props) {
//   return <div>RandomNumber = Math.floor(Math.random() * 100) + 1 ;</div>;
// }

// export default Generator;

// function getRandomInt(max) {
//   return Math.floor(Math.random() * max);
// }
// const myNumber = getRandomInt(1896) + 1;
// console.log(myNumber);

// <form>
//   Generate Random Horses:
//   <div></div>
//   <label for="runners">How many Horses?:</label>
//   <select name="numberOfHorses" value="" onChange={handleChange}></select>
//   <select name="runners" id="runners">
//     <option value="1">1 Horse</option>
//     <option value="2">2 Horses</option>
//     <option value="3">3 Horses</option>
//     <option value="4">4 Horses</option>
//     <option value="5">5 Horses</option>
//     <option value="6">6 Horses</option>
//     <option value="7">7 Horses</option>
//     <option value="8">8 Horses</option>
//     <option value="9">9 Horses</option>
//     <option value="10">10 Horses</option>
//     <option value="11">11 Horses</option>
//   </select>
//   <br />
//   <div> ID # - RandomHorse Name - Starts - Rank - Winning$ - Win %</div>
//   <div>
//     {randomHorseData && (
//       <>
//         {randomHorseData.randomHorseid} -{randomHorseData.randomHorseName} -
//         {randomHorseData.sts}-{randomHorseData.randomHorseRank} -
//         {randomHorseData.randomHorseWinnings} -{randomHorseData.winPercent}%
//       </>
//     )}
//   </div>
// </form>;
