import React from "react";

const Returns = () => {
  return (
    <div>
      <h1 id="productTitle"> Returns</h1>
    </div>
  );
};

export default Returns;
