import React from "react";

// import data from "./Cart";

const Reciept = () => {
  return (
    <div>
      <h1>RECIEPT</h1>
    </div>
  );
};

export default Reciept;
