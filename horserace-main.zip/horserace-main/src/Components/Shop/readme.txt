DONE --- Display Products
Add to cart button (on each product card) Creates record in cart table
Add button will change to # in cart 
Cart component displays after item is added to cart
Return to shopping button on cart

Cards in cart have increment, decrement, whishlist buttons
Whishlist button saves item to wish table 
Qty and price de/increases with items / qty 
Checkout button Navigates to payment page w/credit total payment
Reciept record is created on successful checkout
 
Register button creates a record in the database
Login button checks credentials against the database

