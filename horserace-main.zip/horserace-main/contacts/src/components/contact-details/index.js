import ContactDetailsPage from "./ContactDetailsPage";

export default ContactDetailsPage;