import ContactsPage from "./ContactsPage";

export default ContactsPage;