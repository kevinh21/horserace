import ContactCreateForm from "./ContactCreateForm";

const ContactCreatePage = () => {
    return (
        <div>
            <ContactCreateForm />
        </div>
    )
}

export default ContactCreatePage;