import ContactCreatePage from "./ContactCreatePage";

export default ContactCreatePage;